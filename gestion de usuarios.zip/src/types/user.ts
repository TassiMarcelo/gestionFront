export interface User {
    id: string
    cuil: string
    email: string
    nombre: string
    empresa: string
    descripcion: string
    preferencia: boolean
    usuario: string
    password: string
  }
  